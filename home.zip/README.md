Raj Chaphekar (AB), Ethan Hu (AB), Angelina Lum (AC)
CSE 163

To run this program, run main.py.
Output will be images in the same folder.
